
package numerotarea;


public abstract class Numero {
    public abstract int sumar();
    public abstract int restar();
    public abstract int multiplicarPor();
    public abstract int dividirPor();
    
}
