
package numerotarea;


public class Operaciones extends Numero {
  private int n,s,r,m,d;

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public int getS() {
        return s;
    }

    public void setS(int s) {
        this.s = s;
    }

    public int getR() {
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }

    public int getM() {
        return m;
    }

    public void setM(int m) {
        this.m = m;
    }

    public int getD() {
        return d;
    }

    public void setD(int d) {
        this.d = d;
    }
  
    
    @Override
  public int sumar(){
      
       s=n+n;
      return s;
  }
  
  
    @Override
     public int restar(){
         
         r=n-n;
        return r;
    }
  
  
  @Override
  public int multiplicarPor(){
      m=n*n;
     return m;
  }
  
  
  @Override
  public int dividirPor(){
      
      d=n/n;
      return d;
  }

  
  
}
